package sample.model;

//Classe clinte, filho de Pessoa2
public final class Cliente extends Pessoa2 {
}
