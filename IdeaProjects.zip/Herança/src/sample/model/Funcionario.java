package sample.model;

//Classe Funcionario, filho de Pessoa2
public final class Funcionario extends Pessoa2 {
}
