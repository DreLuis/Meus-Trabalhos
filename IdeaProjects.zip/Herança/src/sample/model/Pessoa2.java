package sample.model;

//calsse pessoa2
public class Pessoa2 {
}
